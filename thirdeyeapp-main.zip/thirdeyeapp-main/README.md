# thirdeye
front end of the app

